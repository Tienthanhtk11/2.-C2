﻿namespace SMS_Services.Model
{
    public class ClaimModel
    {
        public long id { get; set; }
        public string user_name { get; set; } = string.Empty;
        public string email { get; set; } = string.Empty;
        public string name { get; set; } = string.Empty;
       

    }
}
