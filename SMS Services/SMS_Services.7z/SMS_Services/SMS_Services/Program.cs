using Microsoft.EntityFrameworkCore;
using SMS_Services.Background;
using SMS_Services.Model;
using SMS_Services.Repository;

var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
var contexOptions = new DbContextOptionsBuilder<ApplicationDbContext>().UseSqlServer(connectionString).Options;
builder.Services.AddDbContext<ApplicationDbContext>(x => x.UseSqlServer(connectionString));

builder.Services.AddTransient<ISMSRepository, SMSRepository>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//builder.Services.AddHostedService<SendSMS_Cronjob_Services>();
//builder.Services.AddHostedService<ReadSMS_Cronjob_Services>();

builder.Services.AddSwaggerGen();
string issuer = builder.Configuration["Jwt:Issuer"].ToString();
string key = builder.Configuration["Jwt:Key"].ToString();
string audience = builder.Configuration["Jwt:Audience"].ToString();

builder.Services.AddHttpContextAccessor();
builder.Services.AddAuthorization();

builder.Services.AddSwaggerGen();

builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy",
                    builder => builder.WithOrigins()
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .SetIsOriginAllowed(origin => true)
                    .AllowCredentials());
});

builder.Services.AddControllersWithViews();


builder.Services.AddEndpointsApiExplorer();
var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var dataContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
}
app.MapControllers();
app.UseAuthentication();
app.UseRouting();
app.UseAuthorization();

app.UseSwagger();
app.UseSwaggerUI();
app.UseCors("CorsPolicy");
app.Run();

