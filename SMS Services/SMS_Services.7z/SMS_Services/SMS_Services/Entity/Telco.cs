﻿namespace SMS_Services.Model
{
    enum Telco
    {
        VIETTEL, //viettel
        VMS,//mobifone
        GPC,//vinaphone
        VNM, // vietnammobile
        BEELINE, //gtel
        ITEL, //itelecom
        REDDI,//reddi
        UNSUPPORT,
    }

}
