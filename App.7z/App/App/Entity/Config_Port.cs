﻿using System;

namespace App.Entity
{
    public class Config_Port
    {
        public string Mobile_Carrier { get; set; } = "";
        public string Port_Name { get; set; } = "";
        public string Phone_Number { get; set; } = "";
        public long Customer_Id { get; set; } = 0;
        public long id { get; set; } = 0;
    }
}
